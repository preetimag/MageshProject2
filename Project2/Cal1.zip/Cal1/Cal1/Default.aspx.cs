﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Cal1
{
    public partial class Default : System.Web.UI.Page
    {
        public object FinalAmount { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            if(IsValid)
            {
                int a = Int32.Parse(OriginalAmount.Text);
                int b = Int32.Parse(DiscountAmount.Text);
                String d = Name.Text;
                int c = a - b;
                lblFinalAmount.Text = Convert.ToString("Hi" +  d  + "your answer is" +  c );

            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            OriginalAmount.Text = "";
            DiscountAmount.Text ="";
            Name.Text = "";
            lblFinalAmount.Text = "";
        }
    }
}